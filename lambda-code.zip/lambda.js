"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const core_1 = require("@nestjs/core");
const platform_express_1 = require("@nestjs/platform-express");
const common_1 = require("@nestjs/common");
const app_module_1 = require("./app.module");
const serverless_express_1 = require("@codegenie/serverless-express");
const express = require("express");
let cachedHandler;
async function createApp() {
    const expressApp = express();
    const adapter = new platform_express_1.ExpressAdapter(expressApp);
    const app = await core_1.NestFactory.create(app_module_1.AppModule, adapter, {
        logger: ['error', 'warn'],
        abortOnError: false,
    });
    app.useGlobalPipes(new common_1.ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
    }));
    const corsOrigins = process.env.CORS_ORIGINS
        ? process.env.CORS_ORIGINS.split(',')
        : ['http://localhost:3000'];
    app.enableCors({
        origin: corsOrigins,
        credentials: true,
    });
    app.setGlobalPrefix('api');
    await app.init();
    return expressApp;
}
async function bootstrap() {
    if (!cachedHandler) {
        const expressApp = await createApp();
        cachedHandler = (0, serverless_express_1.configure)({ app: expressApp });
    }
    return cachedHandler;
}
const handler = async (event, context) => {
    const serverlessHandler = await bootstrap();
    return serverlessHandler(event, context);
};
exports.handler = handler;
//# sourceMappingURL=lambda.js.map
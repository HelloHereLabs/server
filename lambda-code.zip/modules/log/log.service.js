"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogService = void 0;
const common_1 = require("@nestjs/common");
const uuid_1 = require("uuid");
const safety_filter_service_1 = require("../safety-filter/safety-filter.service");
let LogService = class LogService {
    constructor(safetyFilterService) {
        this.safetyFilterService = safetyFilterService;
        this.logs = [];
    }
    async createChatLog(createLogDto) {
        const safetyResult = await this.safetyFilterService.checkMessage(createLogDto.originalMessage);
        const chatLog = {
            id: (0, uuid_1.v4)(),
            ...createLogDto,
            isSafe: safetyResult.isSafe,
            riskLevel: safetyResult.riskLevel,
            blockedWords: safetyResult.blockedWords,
            timestamp: Date.now(),
        };
        this.logs.push(chatLog);
        return chatLog;
    }
    async getUserLogs(userId) {
        return this.logs
            .filter(log => log.userId === userId)
            .sort((a, b) => b.timestamp - a.timestamp);
    }
    async getRoomLogs(roomId) {
        return this.logs
            .filter(log => log.roomId === roomId)
            .sort((a, b) => a.timestamp - b.timestamp);
    }
    async getUnsafeLogs() {
        return this.logs
            .filter(log => !log.isSafe)
            .sort((a, b) => b.timestamp - a.timestamp);
    }
    async getLogsByRiskLevel(riskLevel) {
        return this.logs
            .filter(log => log.riskLevel === riskLevel)
            .sort((a, b) => b.timestamp - a.timestamp);
    }
    async deleteLog(logId) {
        const index = this.logs.findIndex(log => log.id === logId);
        if (index > -1) {
            this.logs.splice(index, 1);
            return true;
        }
        return false;
    }
    async getLogStats() {
        const total = this.logs.length;
        const safe = this.logs.filter(log => log.isSafe).length;
        const unsafe = total - safe;
        const riskLevels = {
            low: this.logs.filter(log => log.riskLevel === 'low').length,
            medium: this.logs.filter(log => log.riskLevel === 'medium').length,
            high: this.logs.filter(log => log.riskLevel === 'high').length,
        };
        return { total, safe, unsafe, riskLevels };
    }
};
exports.LogService = LogService;
exports.LogService = LogService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [safety_filter_service_1.SafetyFilterService])
], LogService);
//# sourceMappingURL=log.service.js.map
import { LogService } from './log.service';
import { CreateChatLogDto } from '../../entities/log.entity';
export declare class LogController {
    private readonly logService;
    constructor(logService: LogService);
    createLog(createLogDto: CreateChatLogDto): Promise<import("../../entities/log.entity").ChatLog>;
    getUserLogs(userId: string): Promise<import("../../entities/log.entity").ChatLog[]>;
    getRoomLogs(roomId: string): Promise<import("../../entities/log.entity").ChatLog[]>;
    getUnsafeLogs(): Promise<import("../../entities/log.entity").ChatLog[]>;
    getLogsByRiskLevel(level: 'low' | 'medium' | 'high'): Promise<import("../../entities/log.entity").ChatLog[]>;
    getLogStats(): Promise<{
        total: number;
        safe: number;
        unsafe: number;
        riskLevels: {
            low: number;
            medium: number;
            high: number;
        };
    }>;
    deleteLog(id: string): Promise<{
        success: boolean;
    }>;
}

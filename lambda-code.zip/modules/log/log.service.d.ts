import { ChatLog, CreateChatLogDto } from '../../entities/log.entity';
import { SafetyFilterService } from '../safety-filter/safety-filter.service';
export declare class LogService {
    private readonly safetyFilterService;
    private logs;
    constructor(safetyFilterService: SafetyFilterService);
    createChatLog(createLogDto: CreateChatLogDto): Promise<ChatLog>;
    getUserLogs(userId: string): Promise<ChatLog[]>;
    getRoomLogs(roomId: string): Promise<ChatLog[]>;
    getUnsafeLogs(): Promise<ChatLog[]>;
    getLogsByRiskLevel(riskLevel: 'low' | 'medium' | 'high'): Promise<ChatLog[]>;
    deleteLog(logId: string): Promise<boolean>;
    getLogStats(): Promise<{
        total: number;
        safe: number;
        unsafe: number;
        riskLevels: {
            low: number;
            medium: number;
            high: number;
        };
    }>;
}

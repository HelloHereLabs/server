"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const log_service_1 = require("./log.service");
const auth_guard_1 = require("../auth/auth.guard");
let LogController = class LogController {
    constructor(logService) {
        this.logService = logService;
    }
    async createLog(createLogDto) {
        return this.logService.createChatLog(createLogDto);
    }
    async getUserLogs(userId) {
        return this.logService.getUserLogs(userId);
    }
    async getRoomLogs(roomId) {
        return this.logService.getRoomLogs(roomId);
    }
    async getUnsafeLogs() {
        return this.logService.getUnsafeLogs();
    }
    async getLogsByRiskLevel(level) {
        return this.logService.getLogsByRiskLevel(level);
    }
    async getLogStats() {
        return this.logService.getLogStats();
    }
    async deleteLog(id) {
        const deleted = await this.logService.deleteLog(id);
        return { success: deleted };
    }
};
exports.LogController = LogController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '채팅 로그 생성', description: '새로운 채팅 로그를 생성합니다' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '로그 생성 성공' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], LogController.prototype, "createLog", null);
__decorate([
    (0, common_1.Get)('user/:userId'),
    (0, swagger_1.ApiOperation)({ summary: '사용자 로그 조회', description: '특정 사용자의 채팅 로그를 조회합니다' }),
    (0, swagger_1.ApiParam)({ name: 'userId', description: '사용자 ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '사용자 로그 조회 성공' }),
    __param(0, (0, common_1.Param)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], LogController.prototype, "getUserLogs", null);
__decorate([
    (0, common_1.Get)('room/:roomId'),
    (0, swagger_1.ApiOperation)({ summary: '채팅방 로그 조회', description: '특정 채팅방의 로그를 조회합니다' }),
    (0, swagger_1.ApiParam)({ name: 'roomId', description: '채팅방 ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '채팅방 로그 조회 성공' }),
    __param(0, (0, common_1.Param)('roomId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], LogController.prototype, "getRoomLogs", null);
__decorate([
    (0, common_1.Get)('unsafe'),
    (0, swagger_1.ApiOperation)({ summary: '위험 메시지 조회', description: '유해한 내용이 포함된 메시지들을 조회합니다' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '위험 메시지 조회 성공' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], LogController.prototype, "getUnsafeLogs", null);
__decorate([
    (0, common_1.Get)('risk-level/:level'),
    (0, swagger_1.ApiOperation)({ summary: '위험도별 로그 조회', description: '특정 위험도의 로그를 조회합니다' }),
    (0, swagger_1.ApiParam)({
        name: 'level',
        description: '위험도',
        enum: ['low', 'medium', 'high'],
        example: 'high'
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '위험도별 로그 조회 성공' }),
    __param(0, (0, common_1.Param)('level')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], LogController.prototype, "getLogsByRiskLevel", null);
__decorate([
    (0, common_1.Get)('stats'),
    (0, swagger_1.ApiOperation)({ summary: '로그 통계', description: '전체 로그 통계를 조회합니다' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: '로그 통계 조회 성공',
        schema: {
            type: 'object',
            properties: {
                total: { type: 'number', description: '전체 로그 수' },
                safe: { type: 'number', description: '안전한 로그 수' },
                unsafe: { type: 'number', description: '위험한 로그 수' },
                riskLevels: {
                    type: 'object',
                    properties: {
                        low: { type: 'number' },
                        medium: { type: 'number' },
                        high: { type: 'number' }
                    }
                }
            }
        }
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], LogController.prototype, "getLogStats", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '로그 삭제', description: '특정 로그를 삭제합니다' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '로그 ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '로그 삭제 성공' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], LogController.prototype, "deleteLog", null);
exports.LogController = LogController = __decorate([
    (0, swagger_1.ApiTags)('로그'),
    (0, swagger_1.ApiBearerAuth)('access-token'),
    (0, common_1.Controller)('logs'),
    (0, common_1.UseGuards)(auth_guard_1.AuthGuard),
    __metadata("design:paramtypes", [log_service_1.LogService])
], LogController);
//# sourceMappingURL=log.controller.js.map
export declare class LogModule {
}

export interface SafetyResult {
    isSafe: boolean;
    riskLevel: 'low' | 'medium' | 'high';
    filteredMessage: string;
    blockedWords: string[];
}
export declare class SafetyFilterService {
    private blockedWords;
    checkMessage(message: string): Promise<SafetyResult>;
    private calculateRiskLevel;
    addBlockedWord(word: string): Promise<void>;
    removeBlockedWord(word: string): Promise<void>;
    getBlockedWords(): string[];
}

export declare class SafetyFilterModule {
}

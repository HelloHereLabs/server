"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const auth_service_1 = require("./auth.service");
let AuthController = class AuthController {
    constructor(authService) {
        this.authService = authService;
    }
    async generateToken(userId) {
        return this.authService.generateTokenForUser(userId);
    }
    async startSession(res) {
        const { user, token, expiresAt } = await this.authService.createUserAndToken({
            language: 'ko',
            interests: [],
            purpose: 'tourist',
            location: { latitude: 0, longitude: 0 },
        });
        const cookieMaxAgeDays = parseInt(process.env.COOKIE_MAX_AGE_DAYS || '3');
        res.cookie('token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: cookieMaxAgeDays * 24 * 60 * 60 * 1000
        });
        return res.json({
            message: '토큰이 쿠키로 설정되었습니다',
            user,
            expiresAt
        });
    }
};
exports.AuthController = AuthController;
__decorate([
    (0, common_1.Post)('token/:userId'),
    (0, swagger_1.ApiOperation)({ summary: '사용자 토큰 생성', description: '기존 사용자 ID로 토큰을 생성합니다' }),
    (0, swagger_1.ApiParam)({ name: 'userId', description: '사용자 ID' }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: '토큰 생성 성공',
        schema: {
            type: 'object',
            properties: {
                token: { type: 'string', description: 'JWT 토큰' },
                expiresAt: { type: 'number', description: '만료 시각 (timestamp)' }
            }
        }
    }),
    __param(0, (0, common_1.Param)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "generateToken", null);
__decorate([
    (0, common_1.Post)('start'),
    (0, swagger_1.ApiOperation)({ summary: '세션 시작', description: '사용자를 생성하고 3일 유효기간 토큰을 쿠키로 설정합니다' }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: '토큰 생성 성공',
        schema: {
            type: 'object',
            properties: {
                message: { type: 'string', description: '성공 메시지' },
                user: { type: 'object', description: '생성된 사용자 정보' },
                expiresAt: { type: 'number', description: '만료 시각 (timestamp)' }
            }
        }
    }),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "startSession", null);
exports.AuthController = AuthController = __decorate([
    (0, swagger_1.ApiTags)('인증'),
    (0, common_1.Controller)('auth'),
    __metadata("design:paramtypes", [auth_service_1.AuthService])
], AuthController);
//# sourceMappingURL=auth.controller.js.map
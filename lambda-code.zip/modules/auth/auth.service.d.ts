import { User, CreateUserDto } from '../../entities/user.entity';
import { UserService } from '../user/user.service';
export declare class AuthService {
    private readonly userService;
    private readonly jwtSecret;
    private readonly tokenExpiry;
    constructor(userService: UserService);
    generateToken(user: User): string;
    verifyToken(token: string): any;
    generateTokenForUser(userId: string): Promise<{
        token: string;
        expiresAt: number;
    }>;
    createUserAndToken(createUserDto: CreateUserDto): Promise<{
        user: User;
        token: string;
        expiresAt: number;
    }>;
    startSession(): Promise<{
        token: string;
        expiresAt: number;
    }>;
}

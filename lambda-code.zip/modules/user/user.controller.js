"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const user_service_1 = require("./user.service");
const create_user_dto_1 = require("./dto/create-user.dto");
let UserController = class UserController {
    constructor(userService) {
        this.userService = userService;
    }
    async createUser(createUserDto) {
        return this.userService.createUser(createUserDto);
    }
    async updateUser(id, updateUserDto) {
        return this.userService.updateUser(id, updateUserDto);
    }
    async deleteUser(id) {
        return this.userService.deleteUser(id);
    }
    async getUser(id) {
        return this.userService.findUserById(id);
    }
    async getNearbyUsers(latitude, longitude, radius) {
        return this.userService.findUsersNearby(latitude, longitude, radius);
    }
    async updateUserLocation(id, locationDto) {
        return this.userService.updateUserLocation(id, locationDto.latitude, locationDto.longitude);
    }
    async deactivateUser(id) {
        return this.userService.deactivateUser(id);
    }
};
exports.UserController = UserController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: '사용자 생성', description: '새로운 사용자를 생성합니다' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: '사용자 생성 성공' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_user_dto_1.CreateUserDto]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "createUser", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '사용자 정보 업데이트', description: '사용자 ID로 사용자 정보를 업데이트합니다' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '사용자 ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '사용자 정보 업데이트 성공' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '사용자를 찾을 수 없음' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "updateUser", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '사용자 삭제', description: '사용자 ID로 사용자를 삭제합니다' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '사용자 ID' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: '사용자 삭제 성공',
        schema: {
            type: 'object',
            properties: {
                message: { type: 'string', description: '삭제 성공 메시지' }
            }
        }
    }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '사용자를 찾을 수 없음' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "deleteUser", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: '사용자 조회', description: 'ID로 사용자를 조회합니다' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '사용자 ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '사용자 조회 성공' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: '사용자를 찾을 수 없음' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "getUser", null);
__decorate([
    (0, common_1.Get)('nearby/:latitude/:longitude'),
    (0, swagger_1.ApiOperation)({ summary: '근처 사용자 조회', description: '특정 위치 근처의 사용자들을 조회합니다' }),
    (0, swagger_1.ApiParam)({ name: 'latitude', description: '위도', example: 37.5665 }),
    (0, swagger_1.ApiParam)({ name: 'longitude', description: '경도', example: 126.9780 }),
    (0, swagger_1.ApiQuery)({ name: 'radius', description: '검색 반경(km)', required: false, example: 10 }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '근처 사용자 조회 성공' }),
    __param(0, (0, common_1.Param)('latitude')),
    __param(1, (0, common_1.Param)('longitude')),
    __param(2, (0, common_1.Query)('radius')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, Number]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "getNearbyUsers", null);
__decorate([
    (0, common_1.Patch)(':id/location'),
    (0, swagger_1.ApiOperation)({ summary: '사용자 위치 업데이트', description: '사용자의 위치 정보를 업데이트합니다' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '사용자 ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '위치 업데이트 성공' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "updateUserLocation", null);
__decorate([
    (0, common_1.Patch)(':id/deactivate'),
    (0, swagger_1.ApiOperation)({ summary: '사용자 비활성화', description: '사용자를 비활성화합니다' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: '사용자 ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: '사용자 비활성화 성공' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "deactivateUser", null);
exports.UserController = UserController = __decorate([
    (0, swagger_1.ApiTags)('사용자'),
    (0, swagger_1.ApiBearerAuth)('access-token'),
    (0, common_1.Controller)('users'),
    __metadata("design:paramtypes", [user_service_1.UserService])
], UserController);
//# sourceMappingURL=user.controller.js.map
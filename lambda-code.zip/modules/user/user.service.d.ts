import { User } from '../../entities/user.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { DynamoDBService } from '../database/dynamodb.service';
export declare class UserService {
    private readonly dynamoDBService;
    constructor(dynamoDBService: DynamoDBService);
    createUser(createUserDto: CreateUserDto): Promise<User>;
    findUserById(userId: string): Promise<User>;
    findUsersNearby(latitude: number, longitude: number, radiusKm?: number): Promise<User[]>;
    updateUserLocation(userId: string, latitude: number, longitude: number): Promise<User>;
    updateUser(userId: string, updateUserDto: UpdateUserDto): Promise<User>;
    deleteUser(userId: string): Promise<{
        message: string;
    }>;
    deactivateUser(userId: string): Promise<User>;
}

import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User } from '../../entities/user.entity';
export declare class UserController {
    private readonly userService;
    constructor(userService: UserService);
    createUser(createUserDto: CreateUserDto): Promise<User>;
    updateUser(id: string, updateUserDto: UpdateUserDto): Promise<User>;
    deleteUser(id: string): Promise<{
        message: string;
    }>;
    getUser(id: string): Promise<User>;
    getNearbyUsers(latitude: number, longitude: number, radius?: number): Promise<User[]>;
    updateUserLocation(id: string, locationDto: {
        latitude: number;
        longitude: number;
    }): Promise<User>;
    deactivateUser(id: string): Promise<User>;
}

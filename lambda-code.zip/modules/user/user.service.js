"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const uuid_1 = require("uuid");
const dynamodb_service_1 = require("../database/dynamodb.service");
let UserService = class UserService {
    constructor(dynamoDBService) {
        this.dynamoDBService = dynamoDBService;
    }
    async createUser(createUserDto) {
        const user = {
            userId: (0, uuid_1.v4)(),
            ...createUserDto,
            isActive: true,
            createdAt: Date.now(),
            updatedAt: Date.now(),
        };
        await this.dynamoDBService.put(user);
        return user;
    }
    async findUserById(userId) {
        const user = await this.dynamoDBService.get(userId);
        if (!user) {
            throw new common_1.NotFoundException(`User with ID ${userId} not found`);
        }
        return user;
    }
    async findUsersNearby(latitude, longitude, radiusKm = 10) {
        return await this.dynamoDBService.findNearbyUsers(latitude, longitude, radiusKm);
    }
    async updateUserLocation(userId, latitude, longitude) {
        const updates = {
            location: { latitude, longitude },
            updatedAt: Date.now(),
        };
        return await this.dynamoDBService.update(userId, updates);
    }
    async updateUser(userId, updateUserDto) {
        const updates = {
            ...updateUserDto,
            updatedAt: Date.now(),
        };
        return await this.dynamoDBService.update(userId, updates);
    }
    async deleteUser(userId) {
        await this.findUserById(userId);
        await this.dynamoDBService.delete(userId);
        return { message: `User with ID ${userId} has been deleted` };
    }
    async deactivateUser(userId) {
        const updates = {
            isActive: false,
            updatedAt: Date.now(),
        };
        return await this.dynamoDBService.update(userId, updates);
    }
};
exports.UserService = UserService;
exports.UserService = UserService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [dynamodb_service_1.DynamoDBService])
], UserService);
//# sourceMappingURL=user.service.js.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBService = void 0;
const common_1 = require("@nestjs/common");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
let DynamoDBService = class DynamoDBService {
    constructor() {
        this.tableName = process.env.DYNAMODB_TABLE_NAME || 'hellohere-users';
        const dynamoClient = new client_dynamodb_1.DynamoDBClient({
            region: process.env.AWS_REGION || 'us-west-1',
        });
        this.client = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
    }
    async put(item) {
        const command = new lib_dynamodb_1.PutCommand({
            TableName: this.tableName,
            Item: item,
        });
        await this.client.send(command);
    }
    async get(userId) {
        const command = new lib_dynamodb_1.GetCommand({
            TableName: this.tableName,
            Key: { userId },
        });
        const result = await this.client.send(command);
        return result.Item;
    }
    async update(userId, updates) {
        const updateExpression = Object.keys(updates)
            .map(key => `#${key} = :${key}`)
            .join(', ');
        const expressionAttributeNames = Object.keys(updates)
            .reduce((acc, key) => ({ ...acc, [`#${key}`]: key }), {});
        const expressionAttributeValues = Object.keys(updates)
            .reduce((acc, key) => ({ ...acc, [`:${key}`]: updates[key] }), {});
        const command = new lib_dynamodb_1.UpdateCommand({
            TableName: this.tableName,
            Key: { userId },
            UpdateExpression: `SET ${updateExpression}`,
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
            ReturnValues: 'ALL_NEW',
        });
        const result = await this.client.send(command);
        return result.Attributes;
    }
    async delete(userId) {
        const command = new lib_dynamodb_1.DeleteCommand({
            TableName: this.tableName,
            Key: { userId },
        });
        await this.client.send(command);
    }
    async scanActiveUsers() {
        const command = new lib_dynamodb_1.ScanCommand({
            TableName: this.tableName,
            FilterExpression: 'isActive = :isActive',
            ExpressionAttributeValues: { ':isActive': true },
        });
        const result = await this.client.send(command);
        return result.Items || [];
    }
    async findNearbyUsers(latitude, longitude, radiusKm) {
        const allUsers = await this.scanActiveUsers();
        return allUsers.filter(user => {
            if (!user.location)
                return false;
            const distance = this.calculateDistance(latitude, longitude, user.location.latitude, user.location.longitude);
            return distance <= radiusKm;
        });
    }
    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371;
        const dLat = this.deg2rad(lat2 - lat1);
        const dLon = this.deg2rad(lon2 - lon1);
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }
    deg2rad(deg) {
        return deg * (Math.PI / 180);
    }
};
exports.DynamoDBService = DynamoDBService;
exports.DynamoDBService = DynamoDBService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], DynamoDBService);
//# sourceMappingURL=dynamodb.service.js.map
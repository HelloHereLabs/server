export declare class DynamoDBService {
    private readonly client;
    private readonly tableName;
    constructor();
    put(item: any): Promise<void>;
    get(userId: string): Promise<any>;
    update(userId: string, updates: any): Promise<any>;
    delete(userId: string): Promise<void>;
    scanActiveUsers(): Promise<any[]>;
    findNearbyUsers(latitude: number, longitude: number, radiusKm: number): Promise<any[]>;
    private calculateDistance;
    private deg2rad;
}

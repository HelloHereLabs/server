export declare class CreateMatchDto {
    userAId: string;
    userBId: string;
    distance: number;
    interestScore: number;
}

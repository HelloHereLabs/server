export declare const CurrentUser: any;
export declare const UserId: any;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const app_module_1 = require("./app.module");
async function bootstrap() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    app.useGlobalPipes(new common_1.ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
    }));
    const corsOrigins = process.env.CORS_ORIGINS
        ? process.env.CORS_ORIGINS.split(',')
        : ['http://localhost:3000'];
    app.enableCors({
        origin: corsOrigins,
        credentials: true,
    });
    const config = new swagger_1.DocumentBuilder()
        .setTitle(process.env.APP_TITLE || '외국인-시민 매칭 서비스')
        .setDescription(process.env.APP_DESCRIPTION || '외국인과 시민 간의 매칭 및 대화 지원 API')
        .setVersion(process.env.APP_VERSION || '1.0')
        .addBearerAuth({
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        name: 'JWT',
        description: `${process.env.TOKEN_EXPIRY || '3d'} 유효기간 토큰을 입력하세요`,
        in: 'header',
    }, 'access-token')
        .build();
    const document = swagger_1.SwaggerModule.createDocument(app, config);
    swagger_1.SwaggerModule.setup('api', app, document, {
        swaggerOptions: {
            persistAuthorization: true,
        },
    });
    const port = process.env.PORT || 3000;
    await app.listen(port);
    console.log(`Application is running on: ${await app.getUrl()}`);
    console.log(`Swagger documentation: ${await app.getUrl()}/api`);
}
bootstrap();
//# sourceMappingURL=main.js.map